import React, { useState } from "react"

const SearchBar = ({ setDataToShow, dataState, setPage }) => {
  const [userInput, setUserInput] = useState("")
  const [filteredObjects, setFilteredObjects] = useState([])

  const handleInputChange = (event) => {
    const { value } = event.target
    setPage(1)
    setUserInput(value)

    const filtered = dataState.filter((obj) =>
      obj.amount.toString().includes(value)
    )
    setFilteredObjects(filtered)
    // Check if  data exist
    setFilteredObjects(filtered)
    if (filteredObjects.length == "") {
    } else {
      setDataToShow(filteredObjects)
    }
  }

  return (
    <div>
      <input
        type="number"
        value={userInput}
        onChange={handleInputChange}
        placeholder="Search by number"
      />
      <button
        type="submit"
        onClick={() => {
          setDataToShow(dataState), setUserInput("")
        }}
      >
        CLEAR
      </button>
    </div>
  )
}

export default SearchBar
