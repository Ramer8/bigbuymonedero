import { Typography, Box, Button } from "@mui/material"

const SearchDate = ({
  dataToShow, //quitar si no es necesario
  handleDate,
  upperDate,
  lowerDate,
  setUpperDate,
  setLowerDate,
}) => {
  const handleUpperDateChange = (event) => {
    setUpperDate(event.target.value)
  }
  const handleLowerDateChange = (event) => {
    setLowerDate(event.target.value)
  }

  return (
    <Box sx={{ mt: 1 }}>
      <Typography sx={{ mx: 2 }}>
        desde:
        <input
          type="date"
          id="date"
          value={upperDate}
          onChange={handleUpperDateChange}
        />
      </Typography>
      <Typography sx={{ mt: 1, mx: 2 }}>
        hasta:
        <span> </span>
        <input
          type="date"
          id="date"
          value={lowerDate}
          onChange={handleLowerDateChange}
        />
      </Typography>
      <Button sx={{ mx: 6 }} onClick={handleDate}>
        Buscar
      </Button>
    </Box>
  )
}

export default SearchDate
